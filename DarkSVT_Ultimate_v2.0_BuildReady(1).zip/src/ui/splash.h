#pragma once
void showSplashScreen();
